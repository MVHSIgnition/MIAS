if (typeof browser === 'undefined' && typeof chrome !== 'undefined') {
  window.browser = chrome;
}
